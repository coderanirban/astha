<?php


if ( !isset( $_SESSION[ 'admin_email' ] ) ) {

	echo "<script>window.open('login.php','_self')</script>";

} else {




	?>

	<nav class="navbar navbar-inverse navbar-fixed-top">
		<!-- navbar navbar-inverse navbar-fixed-top Starts -->

		<div class="navbar-header">
			<!-- navbar-header Starts -->

			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
				<!-- navbar-ex1-collapse Starts -->


				<span class="sr-only">Toggle Navigation</span>

				<span class="icon-bar"></span>

				<span class="icon-bar"></span>

				<span class="icon-bar"></span>


			</button>
			<!-- navbar-ex1-collapse Ends -->

			<a class="navbar-brand" href="index.php?dashboard">Admin Panel</a>


		</div>
		<!-- navbar-header Ends -->

		
		<!-- nav navbar-right top-nav Ends -->

		<div class="collapse navbar-collapse navbar-ex1-collapse">
			<!-- collapse navbar-collapse navbar-ex1-collapse Starts -->

			<ul class="nav navbar-nav side-nav">
				<!-- nav navbar-nav side-nav Starts -->

				<li>
					<!-- li Starts -->

					<a href="index.php?dashboard">

 Dashboard

</a>

				

				</li>
				<!-- li Ends -->

				<li>
					<!-- Products li Starts -->

					<a href="#" data-toggle="collapse" data-target="#temples"> Manage Temples 

                     <i class="fa fa-fw fa-caret-down"></i>

				   </a>

				

					<ul id="temples" class="collapse">

						<li>
							<a href="index.php?insert_temple"> Add Temples </a>
						</li>

						<li>
							<a href="index.php?view_temples"> View Temples </a>
						</li>


					</ul>

				</li>
				<!-- Products li Ends -->

				<!--<li>
					

					<a href="#" data-toggle="collapse" data-target="#bundles">

<i class="fa fa-fw fa-edit"></i> Bundles

<i class="fa fa-fw fa-caret-down"></i>

</a>

				

					<ul id="bundles" class="collapse">

						<li>
							<a href="index.php?insert_bundle"> Insert Bundle </a>
						</li>

						<li>
							<a href="index.php?view_bundles"> View Bundles </a>
						</li>

					</ul>

				</li>-->
				<!-- Bundles Li Ends --->





				<li>
					<!-- manufacturer li Starts -->

					<a href="#" data-toggle="collapse" data-target="#bramhins">
						<!-- anchor Starts -->

						Manage Brahmins

						<i class="fa fa-fw fa-caret-down"></i>


					</a>
					<!-- anchor Ends -->

					<ul id="bramhins" class="collapse">
						<!-- ul collapse Starts -->

						<li>
							<a href="index.php?insert_bramhin"> Add Brahmins </a>
						</li>

						<li>
							<a href="index.php?view_bramhins"> View Brahmins </a>
						</li>

					</ul>
					<!-- ul collapse Ends -->


				</li>
				<!-- manufacturer li Ends -->


				<!--<li>
					

					<a href="#" data-toggle="collapse" data-target="#p_cat">

<i class="fa fa-fw fa-pencil"></i> Products Categories

<i class="fa fa-fw fa-caret-down"></i>


</a>

				

					<ul id="p_cat" class="collapse">

						<li>
							<a href="index.php?insert_p_cat"> Insert Product Category </a>
						</li>

						<li>
							<a href="index.php?view_p_cats"> View Products Categories </a>
						</li>


					</ul>

				</li>-->
				<!-- li Ends -->


				<!--<li>
					
					<a href="#" data-toggle="collapse" data-target="#cat">

<i class="fa fa-fw fa-arrows-v"></i> Categories

<i class="fa fa-fw fa-caret-down"></i>

</a>

				

					<ul id="cat" class="collapse">

						<li>
							<a href="index.php?insert_cat"> Insert Category </a>
						</li>

						<li>
							<a href="index.php?view_cats"> View Categories </a>
						</li>


					</ul>

				</li>-->
				<!-- li Ends -->



				<!--<li>
				

					<a href="#" data-toggle="collapse" data-target="#store">

<i class="fa fa-fw fa-briefcase"></i> Stores

<i class="fa fa-fw fa-caret-down"></i>

</a>

				

					<ul id="store" class="collapse">

						<li>
							<a href="index.php?insert_store"> Insert store </a>
						</li>

						<li>
							<a href="index.php?view_store"> View store </a>
						</li>

					</ul>

				</li>-->
				<!-- store section li Ends -->


					<!--	<li>
				
					<a href="#" data-toggle="collapse" data-target="#contact_us">
					
					 Contact Enquiry

						<i class="fa fa-fw fa-caret-down"></i>

					</a>
					
					<ul id="contact_us" class="collapse">

					<li>

							<a href="index.php?edit_contact_us"> Enquiry List </a>

						</li>

					<li>

							<a href="index.php?insert_enquiry"> Insert Enquiry Type </a>

						</li>

						<li>

							<a href="index.php?view_enquiry"> View Enquiry Types </a>

						</li>

					</ul>

				</li>-->
				<!-- contact us li Ends -->

				<!-- about us li Starts -->
				<!-- <li>

<a href="index.php?edit_about_us">

<i class="fa fa-fw fa-edit"></i> Edit About Us Page

</a>

</li>    -->
				<!-- about us li Ends -->

		




				<li>

					<a href="index.php?view_customers">  Manage Customers </a>

				

				</li>

				<li>

					<a href="index.php?view_orders"> Manage Orders </a>

				

				</li>

				<!--<li> <a href="index.php?view_payments"> Manage Payments </a> </li>-->

				<!--<li>


					<a href="#" data-toggle="collapse" data-target="#users">

<i class="fa fa-fw fa-gear"></i> Users

<i class="fa fa-fw fa-caret-down"></i>


</a>

				

					<ul id="users" class="collapse">

						<li>
							<a href="index.php?insert_user"> Insert User </a>
						</li>

						<li>
							<a href="index.php?view_users"> View Users </a>
						</li>

						<li>
							<a href="index.php?user_profile=<?php echo $admin_id; ?>"> Edit Profile </a>
						</li>

					</ul>

				</li>-->
				<!-- li Ends -->

				<li>
					<!-- li Starts -->

					<a href="logout.php">  Log Out </a>

				</li>
				<!-- li Ends -->

			</ul>
			<!-- nav navbar-nav side-nav Ends -->

		</div>
		<!-- collapse navbar-collapse navbar-ex1-collapse Ends -->

	</nav> <!-- navbar navbar-inverse navbar-fixed-top Ends -->

	<?php } ?>